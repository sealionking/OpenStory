import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {DefaultInputWidgetComponent} from './components/default-input-widget/default-input-widget.component';
import {JsonSchemaFormModule} from 'angular2-json-schema-form';
import {SharedModule} from '../shared/shared.module';
import { FieldsetMainWidgetComponent } from './components/fieldset-main-widget/fieldset-main-widget.component';
import { FieldRootWidgetComponent } from './components/field-root-widget/field-root-widget.component';
import { TextareaFormatWidgetComponent } from './components/textarea-format-widget/textarea-format-widget.component';
import { TitleWidgetComponent } from './components/title-widget/title-widget.component';
import { SelectCustomWidgetComponent } from './components/select-widget/select-widget.component';
import { AddButtonWidgetComponent } from './components/add-button-widget/add-button-widget.component';
import { SubmitWidgetComponent } from './components/submit-widget/submit-widget.component';
import { BooleanWidgetComponent } from './components/boolean-widget/boolean-widget.component';
import { RadioWidgetComponent } from './components/radio-widget/radio-widget.component';
import { CheckboxWidgetComponent } from './components/checkbox-widget/checkbox-widget.component';
import { OsDateWidgetComponent } from './components/os-date-widget/os-date-widget.component';


@NgModule({
    imports: [
        CommonModule,
        JsonSchemaFormModule,
        SharedModule
    ],
    declarations: [
        DefaultInputWidgetComponent,
        FieldsetMainWidgetComponent,
        FieldRootWidgetComponent,
        TextareaFormatWidgetComponent,
        TitleWidgetComponent,
        SelectCustomWidgetComponent,
        AddButtonWidgetComponent,
        SubmitWidgetComponent,
        BooleanWidgetComponent,
        RadioWidgetComponent,
        CheckboxWidgetComponent,
        OsDateWidgetComponent
    ],
    exports: [],
    entryComponents: [
        DefaultInputWidgetComponent,
        FieldsetMainWidgetComponent,
        FieldRootWidgetComponent,
        TextareaFormatWidgetComponent,
        TitleWidgetComponent,
        SelectCustomWidgetComponent,
        AddButtonWidgetComponent,
        SubmitWidgetComponent,
        BooleanWidgetComponent,
        RadioWidgetComponent,
        CheckboxWidgetComponent,
        OsDateWidgetComponent
    ]
})
export class CustomWidgetsModule {
}
