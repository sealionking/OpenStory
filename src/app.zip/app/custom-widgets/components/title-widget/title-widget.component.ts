import {Component, Input, OnInit, ViewEncapsulation} from '@angular/core';
import {AbstractControl} from '@angular/forms';

import {JsonSchemaFormService} from 'angular2-json-schema-form';

@Component({
    selector: 'app-title-widget',
    encapsulation: ViewEncapsulation.None,
    template: `
        <div [class]="'d-flex'">
            <input
                    [formControl]="formControl"
                    [attr.aria-describedby]="'control' + layoutNode?._id + 'Status'"
                    [attr.list]="'control' + layoutNode?._id + 'Autocomplete'"
                    [attr.maxlength]="options?.maxLength"
                    [attr.minlength]="options?.minLength"
                    [attr.pattern]="options?.pattern"
                    [attr.required]="options?.required"
                    [placeholder]="options?.placeholder"
                    [class]="'title-field-widget w-100'"
                    [name]="controlName"
                    [type]="layoutNode?.type"
                    [value]="controlValue"
                    (input)="updateValue($event)"
            >
        </div>`,
    styleUrls: ['./title-widget.component.scss']
})
export class TitleWidgetComponent implements OnInit {
    formControl: AbstractControl;
    controlName: string;
    controlValue: string;
    options: any;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(private jsf: JsonSchemaFormService) { }

    // TODO: Add several functionalities
    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.jsf.initializeControl(this);
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        this.jsf.updateValue(this, event.target.value);
    }

}
