import {Component, OnInit, Input, ViewEncapsulation, trigger} from '@angular/core';
import {AbstractControl} from '@angular/forms';

import {JsonSchemaFormService} from 'angular2-json-schema-form';

@Component({
    selector: 'app-textarea-format-widget',
    encapsulation: ViewEncapsulation.None,
    template: `
        <div [ngClass]="{'to-red' : options?.required === true && !controlValue}">
            <ckeditor *ngIf="options?.osFormat == 'basic_html'"
                      [config]="ckeConfig"
                      (change)="updateValue($event)"
                      [(ngModel)]="controlValue"
            >
            </ckeditor>
        </div>
        <div *ngIf="!options?.osFormat"
             [class]="'d-flex'">
            <span *ngIf="!controlValue && options?.required" [ngClass]="{'required-red': options.required === true}"></span>
            <textarea
                    [formControl]="formControl"
                    [attr.aria-describedby]="'control' + layoutNode?._id + 'Status'"
                    [attr.maxlength]="options?.maxLength"
                    [attr.minlength]="options?.minLength"
                    [attr.pattern]="options?.pattern"
                    [attr.placeholder]="options?.placeholder"
                    [attr.readonly]="options?.readonly ? 'readonly' : null"
                    [attr.required]="options?.required"
                    [class]="'summary-widget'"
                    [id]="'control' + layoutNode?._id"
                    [name]="controlName"
                    (input)="updateValue($event)"
            ></textarea>
        </div>
    `,
    styleUrls: ['./textarea-format-widget.component.scss']
})
export class TextareaFormatWidgetComponent implements OnInit {
    controlName: string;
    controlValue: any;
    formControl: AbstractControl;
    options: any;
    ckeConfig: any;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(private jsf: JsonSchemaFormService) {
    }

    /**
     * @ignore
     */
    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.jsf.initializeControl(this);
        this.ckeConfig = {
            uiColor: '#EFF0F3',
            allowedContent: false,
            contenteditable: true,
            toolbar: [
                {name: 'insert', items: ['Image']},
                {name: 'basicStyle', items: ['Bold', 'Italic']},
                {name: 'paragraph', items: ['BulletedList', 'NumberedList', 'Blockquote']},
                {name: 'styles', items: ['Styles', 'Format']},
                {name: 'clipboard', items: ['Undo', 'Redo']}
            ]
        };
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        if (this.options.osFormat === 'basic_html') {
            this.jsf.updateValue(this, event);
        } else {
            this.jsf.updateValue(this, event.target.value);
        }
    }
}
