import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TextareaFormatWidgetComponent } from './textarea-format-widget.component';

describe('TextareaFormatWidgetComponent', () => {
  let component: TextareaFormatWidgetComponent;
  let fixture: ComponentFixture<TextareaFormatWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TextareaFormatWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextareaFormatWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
