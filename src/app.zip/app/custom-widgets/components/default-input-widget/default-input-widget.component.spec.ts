import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultInputWidgetComponent } from './default-input-widget.component';

describe('DefaultInputWidgetComponent', () => {
  let component: DefaultInputWidgetComponent;
  let fixture: ComponentFixture<DefaultInputWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultInputWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultInputWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
