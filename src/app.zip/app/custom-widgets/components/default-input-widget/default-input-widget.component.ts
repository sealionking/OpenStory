import {Component, OnInit, Input, ViewEncapsulation, ViewChildren, QueryList} from '@angular/core';

import {JsonSchemaFormService} from 'angular2-json-schema-form';
import { TooltipDirective } from 'ngx-bootstrap/tooltip';


@Component({
    selector: 'app-default-input-widget',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './default-input-widget.component.html',
    styleUrls: ['./default-input-widget.component.scss']
})
export class DefaultInputWidgetComponent implements OnInit {
    @ViewChildren(TooltipDirective) tooltips: QueryList<TooltipDirective>;
    controlName: string;
    controlValue: any;
    customError = false;
    numberCheck = false;
    count: number;
    options: any;
    allowDecimal = true;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(private jsf: JsonSchemaFormService) {
        this.count = 0;
    }

    // TODO: Add several functionalities
    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.jsf.initializeControl(this);
        if (this.layoutNode.dataType === 'integer') {
            this.allowDecimal = false;
        }
        if (this.layoutNode.type === 'number') {
            this.numberCheck = true;
        }
        if (this.options.hasOwnProperty('isUnknown') && this.options['isUnknown'] === true) {
            this.options['required'] = false;
        }
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        if (this.numberCheck) {
            if (event.data === 'e') {
                event.target.value = '';
                this.customError = true;
            } else {
                this.customError = false;
            }
            if (this.customError === true) {
                this.openAll();
                setTimeout(() => {this.closeAll(); }, 2000);
            }
        }
        this.jsf.updateValue(this, event.target.value);
    }

    /**
     * Closes tooltip
     */
    closeAll() {
        this.tooltips.forEach((tooltip: TooltipDirective) => {
            tooltip.hide();
        });
    }

    /**
     * Opens tooltip
     */
    openAll() {
        this.tooltips.forEach((tooltip: TooltipDirective) => {
            tooltip.show();
        });
    }
}
