import {Component, Input, OnInit, ViewEncapsulation} from '@angular/core';

import {JsonSchemaFormService} from 'angular2-json-schema-form';
import {buildTitleMap} from 'angular2-json-schema-form';
import {AbstractControl} from '@angular/forms';

@Component({
    selector: 'app-select-widget',
    encapsulation: ViewEncapsulation.Native,
    template: `
        <div [class]="'position-relative'">
            <span *ngIf="options?.required === true" class="to-red"></span>
            <ng-select
                    [items]="selectList"
                    bindLabel="name"
                    bindValue="value"
                    [searchable]="false"
                    [closeOnSelect]="true"
                    [clearable]="false"
                    [placeholder]="options?.placeholder"
                    [attr.required]="options?.required"
                    [attr.readonly]="options?.readonly ? 'readonly' : null"
                    (change)="updateValue($event)"
                    [formControl]="formControl"
            >
            </ng-select>
            <span *ngIf="options?.osDescription"
                  [class]="'select-description'"
                  [innerHtml]="options?.osDescription"
            ></span>
        </div>`,
    styleUrls: ['./select-widget.component.scss']
})
export class SelectCustomWidgetComponent implements OnInit {
    formControl: AbstractControl;
    options: any;
    selectList: any[];
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(
        private jsf: JsonSchemaFormService
    ) {
    }

    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.selectList = buildTitleMap(
            this.options.titleMap || this.options.enumNames,
            this.options.enum, !!this.options.required, true
        );
        this.jsf.initializeControl(this);
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    // TODO: Implement option for multiple select currently dependent to jsf updateValue function
    updateValue(event) {
        for (let i = 0; i < event.length; i++) {
            this.jsf.updateValue(this, event.target.value);
        }
    }
}
