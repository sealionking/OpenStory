import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';

import {JsonSchemaFormService} from 'angular2-json-schema-form';


@Component({
    selector: 'app-add-button-widget',
    template: `
        <button *ngIf="showAddButton"
                [class]="'btn-add'"
                [disabled]="options?.readonly"
                (click)="addItem($event)">
            Add more
        </button>`,
    changeDetection: ChangeDetectionStrategy.Default,
    styleUrls: ['./add-button-widget.component.scss']
})
export class AddButtonWidgetComponent implements OnInit {
    controlValue: any;
    options: any;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(
        private jsf: JsonSchemaFormService
    ) {
    }

    ngOnInit() {
        this.options = this.layoutNode.options || {};
    }

    /**
     * Allows us to add fields depending on the maxItems from the CMS
     * @return {boolean}
     */
    get showAddButton(): boolean {
        return !this.layoutNode.arrayItem ||
            this.layoutIndex[this.layoutIndex.length - 1] < this.options.maxItems;
    }

    /**
     * Allows us to add one more item till maxItems
     * @param event
     */
    addItem(event) {
        this.controlValue = null;
        event.preventDefault();
        this.jsf.addItem(this);
    }
}
