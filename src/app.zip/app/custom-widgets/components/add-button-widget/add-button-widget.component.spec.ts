import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddButtonWidgetComponent } from './add-button-widget.component';

describe('AddButtonWidgetComponent', () => {
  let component: AddButtonWidgetComponent;
  let fixture: ComponentFixture<AddButtonWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddButtonWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddButtonWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
