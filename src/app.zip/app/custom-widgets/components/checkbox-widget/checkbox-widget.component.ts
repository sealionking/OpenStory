import {Component, Input, OnInit, ViewEncapsulation} from '@angular/core';

import {JsonSchemaFormService} from 'angular2-json-schema-form';
import {TitleMapItem} from 'angular2-json-schema-form/src/json-schema-form.service';
import {buildTitleMap} from 'angular2-json-schema-form';

@Component({
    selector: 'app-checkbox-widget',
    encapsulation: ViewEncapsulation.Native,
    template: `
        <div *ngFor="let checkboxItem of checkboxList" [class]="'checkbox-input'"
             [ngClass]="{'to-red': requriedCheck === false && options?.required === true
             }">
            <label [innerHTML]="options?.title"></label>
            <label
                    [attr.for]="'control' + layoutNode?._id + '/' + checkboxItem.value"
                    [class]="'checkbox-container'">
                <input type="checkbox"
                       [attr.required]="options?.required"
                       [checked]="checkboxItem.checked"
                       [disabled]="controlDisabled"
                       [id]="'control' + layoutNode?._id + '/' + checkboxItem?.value"
                       [name]="checkboxItem?.name"
                       [readonly]="options?.readonly ? 'readonly' : null"
                       [value]="checkboxItem.value"
                       (change)="updateValue($event)">
                <span class="checkmark"></span>
            </label>
            <span [innerHTML]="checkboxItem.name" class="check-title"></span>
            <span *ngIf="options?.osDescription"
                  [class]="'json-checkbox-description'"
                  [innerHtml]="options?.osDescription"
            ></span>
        </div>`,
    styleUrls: ['./checkbox-widget.component.scss']
})
export class CheckboxWidgetComponent implements OnInit {
    controlDisabled = false;
    boundControl = true;
    options: any;
    checkboxList: TitleMapItem[] = [];
    requriedCheck = false;
    countListItems: number;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(private jsf: JsonSchemaFormService) {
    }

    // TODO: Add several functionalities
    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.jsf.initializeControl(this);
        this.checkboxList = buildTitleMap(
            this.options.titleMap || this.options.enumNames, this.options.enum, true
        );
        if (this.boundControl) {
            const formArray = this.jsf.getFormControl(this);
            this.checkboxList.forEach(checkboxItem =>
                checkboxItem.checked = formArray.value.includes(checkboxItem.value)
            );
        }
        if (this.layoutNode.options.hasOwnProperty('required')) {
            for (const item in this.checkboxList) {
                if (this.checkboxList[item] instanceof Object) {
                    const checkItem = this.checkboxList[item];
                    for (const i in checkItem) {
                        if (i === 'checked') {
                            if (checkItem[i] === true) {
                                this.countListItems = 0;
                                this.requriedCheck = true;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        this.countListItems = 0;
        for (const item of this.checkboxList) {
            if (event.target.value === item.value) {
                item.checked = event.target.checked;
                if (item.checked === true) {
                    this.countListItems = 1;
                    this.requriedCheck = true;
                }
            } else if (item.checked === true) {
                this.countListItems = 1;
                this.requriedCheck = true;
            }
        }
        if (this.countListItems === 0) {
            this.requriedCheck = false;
        }
        this.jsf.updateArrayCheckboxList(this, this.checkboxList);
    }
}
