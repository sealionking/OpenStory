import {Component, Input, OnInit, ViewEncapsulation} from '@angular/core';

import {JsonSchemaFormService} from 'angular2-json-schema-form';

@Component({
    selector: 'app-boolean-widget',
    encapsulation: ViewEncapsulation.Native,
    template: `
        <div [class]="'checkbox-input'">
            <label
                    [attr.for]="'control' + layoutNode?._id"
                    [class]="'checkbox-container'">
                <input
                        [checked]="isChecked ? 'checked': null"
                        [disabled]="controlDisabled"
                        [id]="'control' + layoutNode?._id"
                        [name]="controlName"
                        [readonly]="options?.readonly ? 'readonly' : null"
                        [value]="controlValue"
                        type="checkbox"
                        (change)="updateValue($event)">
                <span class="checkmark"></span>
                <span *ngIf="!controlValue && options?.required" [ngClass]="{'checkbox-red': options.required === true}"
                ></span>
            </label>
            <span *ngIf="options?.osBoolTitle"
                  class="widget-title"
                  [innerHTML]="options?.osBoolTitle"></span>
            <span *ngIf="options?.osDescription"
                  [class]="'json-bool-description'"
                  [innerHtml]="options?.osDescription"
            ></span>
        </div>`,
    styleUrls: ['./boolean-widget.component.scss']
})
export class BooleanWidgetComponent implements OnInit {
    controlName: string;
    controlValue: any;
    controlDisabled = false;
    options: any;
    trueValue: any = true;
    falseValue: any = false;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(
        private jsf: JsonSchemaFormService
    ) {
    }

    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.jsf.initializeControl(this);
        if (this.controlValue === null || this.controlValue === undefined) {
            this.controlValue = this.options.title;
        }
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        this.jsf.updateValue(this, event.target.checked ? this.trueValue : this.falseValue);
    }

    get isChecked() {
        return this.jsf.getFormControlValue(this) === this.trueValue;
    }

}
