import {Component, OnInit, Input, ViewEncapsulation} from '@angular/core';

import {JsonSchemaFormService} from 'angular2-json-schema-form';
import {buildTitleMap} from 'angular2-json-schema-form';

@Component({
    selector: 'app-radio-widget',
    encapsulation: ViewEncapsulation.Native,
    template: `
        <div *ngFor="let radioItem of radiosList"
             [class]="'radio-container'">
            <label
                    [attr.for]="'control' + layoutNode?._id + '/' + radioItem?.value"
                    [class]="'checkbox-container'">
                <input type="radio"
                       [attr.aria-describedby]="'control' + layoutNode?._id + 'Status'"
                       [attr.readonly]="options?.readonly ? 'readonly' : null"
                       [attr.required]="options?.required"
                       [checked]="radioItem?.value === controlValue"
                       [class]="options?.fieldHtmlClass || ''"
                       [id]="'control' + layoutNode?._id + '/' + radioItem?.value"
                       [name]="controlName"
                       [value]="radioItem?.value"
                       (change)="updateValue($event)"
                >
                <span class="checkmark"></span>
                <span *ngIf="!controlValue && options?.required" [ngClass]="{'radio-red': options.required === true}"
                ></span>
            </label>
            <span [innerHTML]="radioItem?.name" class="widget-title"></span>
                <span *ngIf="options?.osDescription"
                      [class]="'json-radio-description'"
                      [innerHtml]="options?.osDescription"
            ></span>
        </div>`,
    styleUrls: ['./radio-widget.component.scss']
})
export class RadioWidgetComponent implements OnInit {
    controlName: string;
    controlValue: any;
    options: any;
    radiosList: any[] = [];
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(
        private jsf: JsonSchemaFormService
    ) {
    }

    // TODO: Add several functionalities
    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.radiosList = buildTitleMap(
            this.options.titleMap || this.options.enumNames,
            this.options.enum, true
        );
        this.jsf.initializeControl(this);
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        this.jsf.updateValue(this, event.target.value);
    }
}
