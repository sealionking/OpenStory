import {Component, Input} from '@angular/core';

import {JsonSchemaFormService} from 'angular2-json-schema-form';

@Component({
    selector: 'app-field-root-widget',
    template: `
        <div *ngFor="let layoutItem of layout; let i = index">
            <div>
                <select-framework-widget *ngIf="showWidget(layoutItem)"
                                         [dataIndex]="layoutItem?.arrayItem ? (dataIndex || []).concat(i) : (dataIndex || [])"
                                         [layoutIndex]="(layoutIndex || []).concat(i)"
                                         [layoutNode]="layoutItem">
                </select-framework-widget>
            </div>
        </div>`
})
export class FieldRootWidgetComponent {
    options: any;
    @Input() dataIndex: number[];
    @Input() layoutIndex: number[];
    @Input() layout: any[];
    @Input() isOrderable: boolean;
    @Input() isFlexItem = false;

    constructor(
        private jsf: JsonSchemaFormService
    ) {
    }

    showWidget(layoutNode: any): boolean {
        return this.jsf.evaluateCondition(layoutNode, this.dataIndex);
    }

}
