import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldRootWidgetComponent } from './field-root-widget.component';

describe('FieldRootWidgetComponent', () => {
  let component: FieldRootWidgetComponent;
  let fixture: ComponentFixture<FieldRootWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldRootWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldRootWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
