import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OsDateWidgetComponent } from './os-date-widget.component';

describe('OsDateWidgetComponent', () => {
  let component: OsDateWidgetComponent;
  let fixture: ComponentFixture<OsDateWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OsDateWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OsDateWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
