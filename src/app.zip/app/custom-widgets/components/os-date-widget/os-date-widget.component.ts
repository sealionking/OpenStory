import {Component, Input, OnInit, ViewEncapsulation} from '@angular/core';
import {AbstractControl} from '@angular/forms';

import {JsonSchemaFormService} from 'angular2-json-schema-form';

@Component({
    selector: 'app-os-date-widget',
    encapsulation: ViewEncapsulation.Native,
    template: `
        <div [class]="'d-flex'">
            <span *ngIf="!controlValue && options?.required" [ngClass]="{'required-red': options.required === true}"></span>
            <label *ngIf="options?.title"
                   [style.display]="options?.notitle ? 'none' : ''"
                   [innerHTML]="options?.title"></label>
            <input
                    [attr.aria-describedby]="'control' + layoutNode?._id + 'Status'"
                    [attr.required]="options?.required"
                    [placeholder]="options?.placeholder"
                    [name]="controlName"
                    [type]="'date'"
                    [class]="'date-input'"
                    [value]="controlValue"
                    (input)="updateValue($event)"
            >
        </div>`,
    styleUrls: ['./os-date-widget.component.scss']
})
export class OsDateWidgetComponent implements OnInit {
    controlName: string;
    controlValue: string;
    options: any;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(private jsf: JsonSchemaFormService) {
    }

    // TODO: Add several functionalities
    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.jsf.initializeControl(this);
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        this.jsf.updateValue(this, event.target.value);
    }

}
