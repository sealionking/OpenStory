import {Component, Input, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
    selector: 'app-fieldset-main-widget',
    encapsulation: ViewEncapsulation.None,
    template: `
        <label *ngIf="options?.fieldTitle"
               class="d-flex label-title-control"
               [ngClass]="{'label-tower': !options?.border}"
        >{{options?.fieldTitle}}  <span *ngIf="options?.required" class="form-required-red">*</span></label>
        <label *ngIf="options?.olive" style="margin-top: 25px"></label>

        <fieldset *ngIf="containerType === 'fieldset'"
                  [disabled]="options?.readonly"
                  [attr.required]="options?.required"
        >
            <label *ngIf="options?.required && options?.top" class="form-title-required-red">*</label>
            <label *ngIf="options?.required && options?.bolt" class="form-boolean-required-red">*</label>
            <app-field-root-widget
                    [dataIndex]="dataIndex"
                    [layout]="layoutNode.items"
                    [layoutIndex]="layoutIndex"
            >
            </app-field-root-widget>
        </fieldset>
    `,
    styleUrls: ['./fieldset-main-widget.component.scss']
})
export class FieldsetMainWidgetComponent implements OnInit {
    options: any;
    containerType: string;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor() {
    }

    ngOnInit() {
        switch (this.layoutNode.type) {
            case 'fieldset':
            case 'array':
            case 'tab':
            case 'advancedfieldset':
            case 'authfieldset':
            case 'optionfieldset':
            case 'selectfieldset':
                this.containerType = 'fieldset';
                break;
            default:
                this.containerType = 'fieldset';
                break;
        }
        this.options = this.layoutNode.options || {};
    }
}
