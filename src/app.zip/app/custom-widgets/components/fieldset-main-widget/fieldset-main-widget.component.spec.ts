import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldsetMainWidgetComponent } from './fieldset-main-widget.component';

describe('FieldsetMainWidgetComponent', () => {
  let component: FieldsetMainWidgetComponent;
  let fixture: ComponentFixture<FieldsetMainWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldsetMainWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldsetMainWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
