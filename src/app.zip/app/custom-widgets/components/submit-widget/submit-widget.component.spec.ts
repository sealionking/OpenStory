import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmitWidgetComponent } from './submit-widget.component';

describe('SubmitWidgetComponent', () => {
  let component: SubmitWidgetComponent;
  let fixture: ComponentFixture<SubmitWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmitWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
