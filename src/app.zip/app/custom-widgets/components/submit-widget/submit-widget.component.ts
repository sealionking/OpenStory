import {Component, OnInit, Input, ViewEncapsulation} from '@angular/core';
import { AbstractControl } from '@angular/forms';

import {JsonSchemaFormService} from 'angular2-json-schema-form';

@Component({
  selector: 'app-submit-widget',
    encapsulation: ViewEncapsulation.None,
    template: `
        <div [class]="'submit-container'">
            <div [class]="'top-line'"></div>
            <input  [attr.aria-describedby]="'control' + layoutNode?._id + 'Status'"
                    [attr.readonly]="options?.readonly ? 'readonly' : null"
                    [attr.required]="options?.required"
                    [class]="'btn-submit'"
                    [disabled]="controlDisabled"
                    [id]="'control' + layoutNode?._id"
                    [name]="controlName"
                    [type]="layoutNode?.type"
                    [value]="controlValue"
                    (click)="updateValue($event)">
        </div>`,
  styleUrls: ['./submit-widget.component.scss']
})
export class SubmitWidgetComponent implements OnInit {
    controlValue: any;
    controlName: string;
    value: any;
    controlDisabled;
    options: any;
    @Input() layoutNode: any;
    @Input() layoutIndex: number[];
    @Input() dataIndex: number[];

    constructor(private jsf: JsonSchemaFormService) { }

    ngOnInit() {
        this.options = this.layoutNode.options || {};
        this.jsf.initializeControl(this);
        if (this.controlValue === null || this.controlValue === undefined) {
            this.controlValue = this.options.title;
        }
    }

    /**
     * Allows us to update the formData in order to save it
     * @param event
     */
    updateValue(event) {
        if (typeof this.options.onClick === 'function') {
            this.options.onClick(event);
        } else {
            this.jsf.updateValue(this, event.target.value);
        }
    }

}
