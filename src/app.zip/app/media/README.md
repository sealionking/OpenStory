#Media Module
The Media library is a module that gathers and displays files from the CMS.

The content shown, contains the file name and extension, the author that posted it and the data that it was posted on.

Also we can see the length of the file being measured in resolution or duration
