import {Component, OnInit} from '@angular/core';

import {WebsocketService} from '../core/services/websocket.service';
import {AuthenticateService} from '../core/services/authenticate.service';
import {UserData} from '../shared/model/user-data';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    show = false;
    userJWTData: UserData;
    constructor(
        private auth: AuthenticateService) {
    }

    ngOnInit() {
        this.getUserInfo();
    }

    submitLogout(): void {
        this.auth.logout();
    }

    getUserInfo() {
        this.userJWTData = this.auth.getUserInfo();
    }
}
