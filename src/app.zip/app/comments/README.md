#Comments Module
The Comments Library is a module that allows us to view content from the CMS.

It will display the title and body of the comment, when it was created, the date when it was modified and the status of the comment. 