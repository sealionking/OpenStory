export interface Content {
    body: string;
    changed: number;
    created: number;
    fieldImage: string;
    osContentPicture: any;
    id: number;
    langcode: string;
    nid: any;
    status: number;
    title: string;
    type: string;
    userId: string;
    username: any;
    viewUrl: string;
    myType: any;
    contentMachineName: any;
}
