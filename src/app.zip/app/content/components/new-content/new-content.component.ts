import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';

import {AuthenticateService} from '../../../core/services/authenticate.service';
import {DefaultInputWidgetComponent} from '../../../custom-widgets/components/default-input-widget/default-input-widget.component';
import {FieldsetMainWidgetComponent} from '../../../custom-widgets/components/fieldset-main-widget/fieldset-main-widget.component';
import {FieldRootWidgetComponent} from '../../../custom-widgets/components/field-root-widget/field-root-widget.component';
import {MessageService} from '../../../core/services/message.service';
import {TextareaFormatWidgetComponent} from '../../../custom-widgets/components/textarea-format-widget/textarea-format-widget.component';
import {TitleWidgetComponent} from '../../../custom-widgets/components/title-widget/title-widget.component';
import {WebsocketService} from '../../../core/services/websocket.service';
import {SelectCustomWidgetComponent} from '../../../custom-widgets/components/select-widget/select-widget.component';
import {AddButtonWidgetComponent} from '../../../custom-widgets/components/add-button-widget/add-button-widget.component';
import {SubmitWidgetComponent} from '../../../custom-widgets/components/submit-widget/submit-widget.component';
import {BooleanWidgetComponent} from '../../../custom-widgets/components/boolean-widget/boolean-widget.component';
import {RadioWidgetComponent} from '../../../custom-widgets/components/radio-widget/radio-widget.component';
import {CheckboxWidgetComponent} from '../../../custom-widgets/components/checkbox-widget/checkbox-widget.component';
import {ContentService} from '../../services/content.service';
import {Ng4SpinnerService} from 'ng4-spinner';
import {OsDateWidgetComponent} from '../../../custom-widgets/components/os-date-widget/os-date-widget.component';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';

@Component({
    selector: 'app-new-content',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './new-content.component.html',
    styleUrls: ['./new-content.component.scss']
})
export class NewContentComponent implements OnInit {
    contentSchema: any = {'default': {}};
    layoutSchema: any;
    initContent = false;
    jsonFormOptions: any = {
        debug: false,
        returnEmptyFields: false,
        validateOnRender: false,
        defautWidgetOptions: {
            feedback: true,
            validationMessages: {
                required: 'This field is required.'
            }
        }
    };
    customWidgets = {
        'string': DefaultInputWidgetComponent,
        'number': DefaultInputWidgetComponent,
        'section': FieldsetMainWidgetComponent,
        'root': FieldRootWidgetComponent,
        'summary': TextareaFormatWidgetComponent,
        'textarea': TextareaFormatWidgetComponent,
        'title': TitleWidgetComponent,
        'select_list': SelectCustomWidgetComponent,
        '$ref': AddButtonWidgetComponent,
        'submit': SubmitWidgetComponent,
        'boolean': BooleanWidgetComponent,
        'radios': RadioWidgetComponent,
        'checkboxes': CheckboxWidgetComponent,
        'email': DefaultInputWidgetComponent,
        'date': OsDateWidgetComponent
    };
    checkboxArray = {};
    contentName: string;
    defaultList = {};
    liveFormData = {};
    errorMessages = {};

    /**
     * @ignore
     */
    constructor(private wsService: WebsocketService,
                private auth: AuthenticateService,
                private messageService: MessageService,
                private route: Router,
                private router: ActivatedRoute,
                private ngSpinner: Ng4SpinnerService,
                private loader: Ng4LoadingSpinnerService,
                private contentService: ContentService) {
        this.contentName = this.router.snapshot.paramMap.get('contenttype');
    }

    /**
     * @ignore
     */
    ngOnInit() {
        this.loader.show();
        this.contentSchemaRequest();
    }

    /**
     * Request for the new content schema
     */
    contentSchemaRequest() {
        this.wsService.sendRequest({
            eventType: 'entity',
            event: 'EntityDefinition', data: {token: this.auth.getToken(), entityType: 'node', bundle: this.getContentName()}
        })
            .subscribe(data => {
                switch (data.statusCode) {
                    case 200:
                        if (this.initContent) {
                            return;
                        } else {
                            this.initContent = true;
                        }
                        for (const m in data.body.form) {
                            if (data.body.form[m].hasOwnProperty('fieldTitle')) {
                                const firstSet = data.body.form[m];
                                if (firstSet.hasOwnProperty('items')) {
                                    const secondSet = firstSet['items'];
                                    if (secondSet.hasOwnProperty('items')) {
                                        const label = secondSet['items'][0];
                                        if (label.hasOwnProperty('type')) {
                                            if (label['type'] === 'title' || label['type'] === 'boolean'
                                                || label['type'] === 'textarea' || label['type'] === 'summary' ) {
                                                delete firstSet['fieldTitle'];

                                            } else if (label['type'] === 'radios' || label['type'] === 'checkboxes'
                                                || label['type'] === 'select_list') {
                                                firstSet['border'] = true;
                                            }
                                            if (label['type'] === 'summary' || label['type'] === 'textarea') {
                                                firstSet['olive'] = true;
                                            }
                                            if (label['type'] === 'boolean') {
                                                firstSet['bolt'] = true;
                                            }
                                            if (label['type'] === 'title') {
                                                firstSet['top'] = true;
                                            }
                                        }
                                    }
                                }
                            }
                            if (data.body.form[m].hasOwnProperty('key')) {
                                const keySet = data.body.form[m];
                                const key = data.body.form[m]['key'];
                                if (key === 'promote') {
                                    keySet['olive'] = true;
                                }
                            }
                        }
                        this.contentSchema = data.body.properties;
                        this.layoutSchema = data.body.form;
                        // TODO: Changed this at refactor
                        this.auth.checkboxCheck(this.layoutSchema, this.checkboxArray);
                        this.auth.neededList(this.contentSchema, this.defaultList);
                        break;
                    case 400:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Bad request.');
                        break;
                    case 403:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Access denied.');
                        break;
                    case 404:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Not Found.');
                        break;
                    case 422:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Unprocessable Entity.');
                        break;
                    case 500:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Internal Server Error.');
                        break;
                    default:
                        this.messageService.add('Connection issues between UI and Server');
                }
                this.loader.hide();
            });
    }

    /**
     * Retreive the content type from the url
     * @return {string | null}
     */
    getContentName() {
        const type = this.router.snapshot.paramMap.get('contenttype');
        return type;
    }

    /**
     * Submit the new content type
     * @param formData
     */
    onSubmitFn(formData): void {
        this.ngSpinner.show();
        const view = {};
        formData = this.contentService.liveDatacheck(this.liveFormData, view, this.checkboxArray);
        this.auth.checkForm(formData, this.checkboxArray, this.defaultList);
        this.wsService.sendRequest({
            eventType: 'content', event: 'CreateEntity', data: {
                token: this.auth.getToken(),
                entityType: 'node', bundle: this.getContentName(), body: formData
            }
        })
            .subscribe(data => {
                switch (data.statusCode) {
                    case 200:
                        this.route.navigate(['/content']);
                        this.messageService.add('Content has been created!', 'success');
                        break;
                    case 400:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Bad request.');
                        break;
                    case 403:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add(data.body);
                        break;
                    case 404:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Not Found.');
                        break;
                    case 422:
                        this.ngSpinner.hide();
                        // TODO: add general messages - bootstrap.
                        this.messageService.add(data.body.message);
                        break;
                    case 500:
                        // TODO: add general messages - bootstrap.
                        this.messageService.add('Internal Server Error.');
                        break;
                    default:
                        this.messageService.add('Connection issues between UI and Server');
                }
                this.ngSpinner.hide();
            });
    }

    /**
     * Allows the user to go back to the users screen
     */
    goBack() {
        this.route.navigate(['/content']);
    }

    /**
     * Save the live data from the form
     * @param data
     */
    onChanges(data: any) {
        this.liveFormData = data;
    }

    /**
     * Allows us to view the JSON form
     * for testing only
     * Just add {{prettyLiveFormData}} in the HTML
     * @return {string}
     */
    get prettyLiveFormData() {
        return JSON.stringify(this.liveFormData, null, 2);
    }
}
