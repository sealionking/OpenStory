# Login Module

The **Login Module** is mainly used to create a `web-socket` connection via
 `socket.IO` with our `nodeJS` server.
 
Allows us to log in the user and keep him logged during his stay.

Allows us to cut the socket connection when logged out.
 