# Users Module 

The **Users Module** is used to display, edit and modify users for the `CMS`.