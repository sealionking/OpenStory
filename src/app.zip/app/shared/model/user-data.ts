export class UserData {
    iat: number;
    mail: string;
    name: string;
    roles: any;
    uid: string;
    userPicture: any;
}