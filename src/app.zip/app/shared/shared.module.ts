import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FilterPipeModule} from 'ngx-filter-pipe';
import {InlineSVGModule} from 'ng-inline-svg';
import {HttpClientModule} from '@angular/common/http';

import {FroalaEditorModule, FroalaViewModule} from 'angular-froala-wysiwyg';
import {MessagesComponent} from './components/messages/messages.component';
import {NgSelectModule} from '@ng-select/ng-select';
import {OrderModule} from 'ngx-order-pipe';
import {TooltipModule} from 'ngx-bootstrap';
import {CKEditorModule} from 'ng2-ckeditor';
import {Ng4SpinnerModule} from 'ng4-spinner';
import {AlertModule} from 'ngx-bootstrap';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        NgSelectModule,
        ReactiveFormsModule,
        FilterPipeModule,
        OrderModule,
        FroalaEditorModule.forRoot(),
        FroalaViewModule.forRoot(),
        HttpClientModule,
        InlineSVGModule,
        TooltipModule.forRoot(),
        CKEditorModule,
        Ng4SpinnerModule,
        AlertModule.forRoot()
    ],
    declarations: [
        MessagesComponent
    ],
    exports: [
        CommonModule,
        MessagesComponent,
        FormsModule,
        NgSelectModule,
        ReactiveFormsModule,
        FilterPipeModule,
        OrderModule,
        FroalaEditorModule,
        FroalaViewModule,
        InlineSVGModule,
        TooltipModule,
        CKEditorModule,
        Ng4SpinnerModule,
        AlertModule
    ]
})
export class SharedModule {
}
